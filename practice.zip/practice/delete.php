<?php
require 'connection.php';
$query="DELETE FROM practice WHERE id =".$_GET["id"];
mysqli_query($connection,$query);
header("Location: select.php");
 
?>
