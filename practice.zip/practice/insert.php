<?php
    require 'connection.php';
    if($_POST["update"]==null)
    {
        $query= "INSERT INTO practice
        (
           `username`,
           `password`,
           `dob`,
           `gender`
       ) VALUES
       (
           '".$_POST["username"]."',
           '".$_POST["password"]."',
           '".$_POST["dob"]."',
           '".$_POST["gender"]."'
       )";
    }
    else
    {
        $query= "UPDATE practice
        SET username='".$_POST["username"]."', 
            password='".$_POST["password"]."', 
            dob='".$_POST["dob"]."',
            gender='".$_POST["gender"]."'
        WHERE id= ".$_POST["update"];
    }
    echo $query;
    
    mysqli_query($connection,$query);

    header("Location: select.php");
?>