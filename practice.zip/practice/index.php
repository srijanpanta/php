<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TEST</title>
</head>
<?php   
    require 'connection.php';
    $id;
    if(isset($_GET["id"]))
    {
        $id=$_GET["id"];
        $query="SELECT * FROM practice WHERE id= ".$id;
        $data=mysqli_query($connection,$query);
        $row=mysqli_fetch_assoc($data);
    }
?>
<body>
   <table>
   <form action="insert.php" method="POST">
   <tr>
    <td><label for="username">Username</label></td>
    <td><input type="text" name="username"  value="<?php if(isset($id)) echo $row['username'];?>"></td>
   </tr>
   <tr>
    <td><label for="password">Password</label></td>
    <td><input type="text" name="password"  value="<?php if(isset($id)) echo $row['username'];?>"></td>
   </tr>
   <tr>
    <td><label for="dob">DOB</label></td>
    <td><input type="date" name="dob"   value="<?php if(isset($id)) echo $row['dob'];?>"></td>
   </tr>
   <tr>   
    <td><label for="gender">Gender</label></td>
    <td><input type="radio" name="gender" value="male">Male
    <input type="radio" name="gender" value="female">Female
    </td>
    <input type="hidden" name="update" value="<?php if(isset($id)) echo $row['id']; else echo null;?>">
   </tr>
   <tr>
    
    <td><input type="Submit"></td>
   </tr>
   
   </form>
</table>
</body>
</html>