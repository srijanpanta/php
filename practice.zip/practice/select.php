<?php
    require 'connection.php';

    $query="SELECT * FROM practice";

    $data = mysqli_query($connection,$query);
?>
<table border=1>
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Password</th>
        <th>DOB</th>
        <th>Gender</th>
        <th>Action</th>
    </tr>

<?php while($row= mysqli_fetch_assoc($data))
    {
?>
<tr>
    <td><?php echo $row["id"]?></td>
    <td><?php echo $row["username"]?></td>
    <td><?php echo $row["password"]?></td>
    <td><?php echo $row["dob"]?></td>
    <td><?php echo $row["gender"]?></td>
    <td><a href="index.php?id=<?php echo $row["id"];?>">Edit</a>/<a href="delete.php?id=<?php echo $row["id"];?> onclick">Delete</a></td>
</tr>
<?php   
    }
?>
</table>